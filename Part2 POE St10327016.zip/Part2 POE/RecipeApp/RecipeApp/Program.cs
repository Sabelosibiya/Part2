﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    // Main class of the application
    class Program
    {
        // Main method where the program starts execution
        static void Main(string[] args)
        {
            // Instantiate a RecipeManager to manage recipes
            RecipeManager recipeManager = new RecipeManager();

            // Main menu loop
            while (true)
            {
                // Display menu options
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("1. Add Recipe");
                Console.WriteLine("2. Display Recipe");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear Recipe");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());
                Console.ResetColor();
                Console.WriteLine();

                // Switch to handle user choice
                switch (choice)
                {
                    case 1:
                        recipeManager.AddRecipe();
                        break;
                    case 2:
                        recipeManager.DisplayRecipes();
                        break;
                    case 3:
                        recipeManager.ScaleRecipe();
                        break;
                    case 4:
                        recipeManager.ResetQuantities();
                        break;
                    case 5:
                        recipeManager.ClearRecipe();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid choice. Please try again.");
                        Console.ResetColor();
                        break;
                }

                Console.WriteLine();
            }
        }
    }

    // Delegate for notifying when a recipe exceeds 300 calories
    delegate void RecipeExceedsCaloriesHandler(string recipeName, decimal totalCalories);

    // Class to manage recipes
    class RecipeManager
    {
        // List to store recipes
        private List<Recipe> recipes;

        // Event for recipe exceeding 300 calories
        public event RecipeExceedsCaloriesHandler RecipeExceedsCalories;

        // Constructor to initialize RecipeManager
        public RecipeManager()
        {
            recipes = new List<Recipe>();
        }

        // Method to add a new recipe
        public void AddRecipe()
        {
            Recipe recipe = new Recipe();
            recipe.AddRecipe();
            recipes.Add(recipe);
        }

        // Method to display all recipes
        public void DisplayRecipes()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Recipes:");
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available.");
            }
            else
            {
                // Sort recipes by name
                recipes = recipes.OrderBy(r => r.Name).ToList();
                foreach (var recipe in recipes)
                {
                    Console.WriteLine(recipe.Name);
                }

                Console.WriteLine("Enter the name of the recipe to display:");
                string recipeName = Console.ReadLine();
                Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name == recipeName);
                if (selectedRecipe != null)
                {
                    selectedRecipe.DisplayRecipe();
                    if (selectedRecipe.TotalCalories > 300)
                    {
                        RecipeExceedsCalories?.Invoke(selectedRecipe.Name, selectedRecipe.TotalCalories);
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Recipe not found.");
                    Console.ResetColor();
                }
            }
        }

        // Method to scale all recipes
        public void ScaleRecipe()
        {
            Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
            decimal factor = decimal.Parse(Console.ReadLine());

            foreach (var recipe in recipes)
            {
                recipe.ScaleRecipe(factor);
            }
        }

        // Method to reset all recipes
        public void ResetQuantities()
        {
            foreach (var recipe in recipes)
            {
                recipe.ResetQuantities();
            }
        }

        // Method to clear all recipes
        public void ClearRecipe()
        {
            recipes.Clear();
        }
    }

    // Class representing a recipe
    class Recipe
    {
        // Properties
        public string Name { get; private set; }
        private List<string> ingredients;
        private List<decimal> quantities;
        private List<string> units;
        private List<decimal> calories;
        private List<string> foodGroups;
        private List<string> steps;

        // Constructor to initialize recipe data
        public Recipe()
        {
            ingredients = new List<string>();
            quantities = new List<decimal>();
            units = new List<string>();
            calories = new List<decimal>();
            foodGroups = new List<string>();
            steps = new List<string>();
        }

        // Method to add a recipe
        public void AddRecipe()
        {
            Console.Write("Enter the name of the recipe: ");
            Name = Console.ReadLine();

            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write("Enter the name of ingredient #{0}: ", i + 1);
                ingredients.Add(Console.ReadLine());

                Console.Write("Enter the quantity of ingredient #{0}: ", i + 1);
                quantities.Add(decimal.Parse(Console.ReadLine()));

                Console.Write("Enter the unit of measurement for ingredient #{0}: ", i + 1);
                units.Add(Console.ReadLine());

                Console.Write("Enter the number of calories for ingredient #{0}: ", i + 1);
                calories.Add(decimal.Parse(Console.ReadLine()));

                Console.Write("Enter the food group for ingredient #{0}: ", i + 1);
                foodGroups.Add(Console.ReadLine());
            }

            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write("Enter step #{0}: ", i + 1);
                steps.Add(Console.ReadLine());
            }
        }

        // Method to display the recipe
        public void DisplayRecipe()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Recipe: {0}", Name);
            Console.WriteLine("Ingredients:");

            for (int i = 0; i < ingredients.Count; i++)
            {
                Console.WriteLine("{0}. {1} {2} - Calories: {3}, Food Group: {4}", i + 1, quantities[i], units[i], calories[i], foodGroups[i]);
            }

            Console.WriteLine("Steps:");

            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, steps[i]);
            }
        }

        // Method to scale the recipe quantities
        public void ScaleRecipe(decimal factor)
        {
            for (int i = 0; i < quantities.Count; i++)
            {
                quantities[i] *= factor;
            }
        }

        // Method to reset all quantity values
        public void ResetQuantities()
        {
            // Clear all lists
            ingredients.Clear();
            quantities.Clear();
            units.Clear();
            calories.Clear();
            foodGroups.Clear();
            steps.Clear();
        }

        // Method to calculate total calories
        public decimal TotalCalories
        {
            get { return calories.Sum(); }
        }
    }

    // Unit test for Recipe class
    class RecipeUnitTest
    {
        public static void TestTotalCalories()
        {
            Recipe recipe = new Recipe();
            recipe.AddRecipe();
            decimal expectedTotalCalories = recipe.TotalCalories;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"Total calories: {expectedTotalCalories}");
            Console.ResetColor();
        }
    }
}